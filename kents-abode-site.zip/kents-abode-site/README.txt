KENTS ABODE HOMESTAY WEBSITE

Files:
- index.html : Complete responsive website

How to use:
1. Open index.html in any browser to preview.
2. Upload index.html to your hosting public_html folder.
3. Replace sample image URLs with your actual property photos when ready.
4. Update the Contact section with your phone, WhatsApp, email, address and Airbnb listing URL.
5. Connect the booking form to WhatsApp, email, Formspree or your own backend before taking live submissions.

Domain suggestion:
- kentsabode.com

Tagline:
- Stay. Relax. Feel at Home.
