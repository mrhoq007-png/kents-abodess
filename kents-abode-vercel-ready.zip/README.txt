Kents Abode - Vercel Ready Package

IMPORTANT:
Upload/deploy the CONTENTS of this package as the project root.
The file index.html must be at the root of the Vercel project.

Vercel settings:
- Framework Preset: Other
- Root Directory: ./
- Build Command: leave empty
- Output Directory: leave empty

Files at project root:
- index.html
- vercel.json

No build step is required.
